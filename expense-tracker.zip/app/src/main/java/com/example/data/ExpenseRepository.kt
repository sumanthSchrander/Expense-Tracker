package com.example.data

import kotlinx.coroutines.flow.Flow

class ExpenseRepository(private val transactionDao: TransactionDao) {
    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactions()

    suspend fun insert(transaction: Transaction) {
        transactionDao.insertTransaction(transaction)
    }

    suspend fun delete(id: Int) {
        transactionDao.deleteTransaction(id)
    }

    suspend fun clearAll() {
        transactionDao.deleteAllTransactions()
    }
}
