package com.example

import android.app.Application
import androidx.room.Room
import com.example.data.ExpenseDatabase
import com.example.data.ExpenseRepository

class ExpenseApplication : Application() {
    val database: ExpenseDatabase by lazy {
        Room.databaseBuilder(
            this,
            ExpenseDatabase::class.java,
            "expense_database"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    val repository: ExpenseRepository by lazy {
        ExpenseRepository(database.transactionDao)
    }
}
