package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Rich custom slate and dark colors
val IndigoPrimary = Color(0xFF6366F1)
val SlateDarkBackground = Color(0xFF0B0F19)
val SlateCardBackground = Color(0xFF151D2F)
val SlateSecondary = Color(0xFF475569)

// Standard transaction colors
val RupeeCreditGreen = Color(0xFF10B981) // Emerald green for credit
val RupeeDebitRed = Color(0xFFEF4444)   // Crimson red for spends
val RupeeGoldAccent = Color(0xFFF59E0B)  // Gold/Amber for warning or budget

// Light mode fallback colors
val LightBackground = Color(0xFFF3F4F9)
val LightCardBackground = Color(0xFFFFFFFF)
val LightPrimary = Color(0xFF4338CA)
val LightSecondary = Color(0xFF64748B)
