package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.ExpenseRepository
import com.example.data.Transaction
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ExpenseViewModel(private val repository: ExpenseRepository) : ViewModel() {

    // Monthly spending budget in INR (default is 30,000 INR)
    val monthlyBudget = MutableStateFlow(30000.0)

    // Filter properties
    val selectedFilterType = MutableStateFlow(FilterType.ALL)
    val selectedCategory = MutableStateFlow<String?>(null)

    // Search query for description / comments
    val searchQuery = MutableStateFlow("")

    val allTransactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Main UI State that applies filters
    val filteredTransactions: StateFlow<List<Transaction>> = combine(
        allTransactions,
        selectedFilterType,
        selectedCategory,
        searchQuery
    ) { txList, filterType, category, query ->
        txList.filter { tx ->
            val matchesType = when (filterType) {
                FilterType.ALL -> true
                FilterType.INCOME -> tx.isIncome
                FilterType.EXPENSE -> !tx.isIncome
            }
            val matchesCategory = category == null || tx.category == category
            val matchesSearch = query.isEmpty() || 
                    tx.title.contains(query, ignoreCase = true) || 
                    tx.note.contains(query, ignoreCase = true)
            
            matchesType && matchesCategory && matchesSearch
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        // Pre-populate with beautiful, clean, helpful dummy transactions if empty
        viewModelScope.launch {
            repository.allTransactions.collect { list ->
                if (list.isEmpty()) {
                    prePopulateSampleData()
                }
            }
        }
    }

    private suspend fun prePopulateSampleData() {
        val sampleTransactions = listOf(
            Transaction(
                title = "Monthly Salary Credited",
                amount = 65000.0,
                isIncome = true,
                category = "Salary",
                note = "Primary monthly corporate salary credit"
            ),
            Transaction(
                title = "House Rent Paid",
                amount = 15000.0,
                isIncome = false,
                category = "Rent",
                note = "Flat No. 302, Phase 1"
            ),
            Transaction(
                title = "Supermarket Grocery Shopping",
                amount = 3450.0,
                isIncome = false,
                category = "Food",
                note = "Monthly stock and snacks"
            ),
            Transaction(
                title = "Swiggy Dinner Order",
                amount = 890.0,
                isIncome = false,
                category = "Food",
                note = "Weekend biryani cravings"
            ),
            Transaction(
                title = "Freelance UI Project Banner",
                amount = 12000.0,
                isIncome = true,
                category = "Bonus",
                note = "Design work for foreign client"
            ),
            Transaction(
                title = "Petrol Refill - Indian Oil",
                amount = 1200.0,
                isIncome = false,
                category = "Travel",
                note = "Bike full tank"
            ),
            Transaction(
                title = "Broadband Internet Bill",
                amount = 799.0,
                isIncome = false,
                category = "Bills",
                note = "Fiber connection"
            ),
            Transaction(
                title = "Amazon Shopping (Noise Cancelling Buds)",
                amount = 2499.0,
                isIncome = false,
                category = "Shopping",
                note = "Replacement sound gear"
            )
        )
        for (tx in sampleTransactions) {
            repository.insert(tx)
        }
    }

    fun addTransaction(title: String, amount: Double, isIncome: Boolean, category: String, note: String) {
        viewModelScope.launch {
            repository.insert(
                Transaction(
                    title = title,
                    amount = amount,
                    isIncome = isIncome,
                    category = category,
                    note = note
                )
            )
        }
    }

    fun deleteTransaction(id: Int) {
        viewModelScope.launch {
            repository.delete(id)
        }
    }

    fun clearAllTransactions() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    fun updateBudget(newBudget: Double) {
        monthlyBudget.value = newBudget
    }

    fun setFilterType(filterType: FilterType) {
        selectedFilterType.value = filterType
    }

    fun toggleCategoryFilter(category: String) {
        if (selectedCategory.value == category) {
            selectedCategory.value = null
        } else {
            selectedCategory.value = category
        }
    }

    fun clearFilters() {
        selectedFilterType.value = FilterType.ALL
        selectedCategory.value = null
        searchQuery.value = ""
    }
}

enum class FilterType {
    ALL, INCOME, EXPENSE
}

class ExpenseViewModelFactory(private val repository: ExpenseRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ExpenseViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ExpenseViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
