package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.Transaction
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import android.content.ClipboardManager
import android.content.ClipData
import android.content.Context
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpenseApp(viewModel: ExpenseViewModel) {
    val transactions by viewModel.filteredTransactions.collectAsState()
    val allTransactionsRaw by viewModel.allTransactions.collectAsState()
    val filterType by viewModel.selectedFilterType.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val monthlyBudgetLimit by viewModel.monthlyBudget.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showBudgetDialog by remember { mutableStateOf(false) }
    var showReportDialog by remember { mutableStateOf(false) }

    // Computations from all transactions raw to keep up-to-date
    val totalCredits = allTransactionsRaw.filter { it.isIncome }.sumOf { it.amount }
    val totalSpends = allTransactionsRaw.filter { !it.isIncome }.sumOf { it.amount }
    val currentBalance = totalCredits - totalSpends
    val budgetProgress = if (monthlyBudgetLimit > 0) (totalSpends / monthlyBudgetLimit).coerceIn(0.0, 2.0) else 0.0

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("add_transaction_fab")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Entry")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add Entry", fontWeight = FontWeight.Bold)
                }
            }
        },
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Welcome Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "S",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 15.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "WELCOME BACK",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(1.dp))
                        Text(
                            text = "Sumanth",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }

                IconButton(
                    onClick = { showBudgetDialog = true },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .testTag("budget_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Set Budget Limit",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f),
                contentPadding = PaddingValues(bottom = 96.dp)
            ) {
                // Item 1: Balance & Statistics Card
                item {
                    BalanceStatsCard(
                        balance = currentBalance,
                        credits = totalCredits,
                        spends = totalSpends,
                        budgetLimit = monthlyBudgetLimit,
                        progress = budgetProgress,
                        onBudgetClick = { showBudgetDialog = true }
                    )
                }

                // Item 1.5: Interactive Monthly Report Banner Launcher
                item {
                    MonthlyReportBanner(
                        onClick = { showReportDialog = true }
                    )
                }

                // Item 2: Quick shortcuts & recommendations
                item {
                    QuickFrictionlessActions(
                        onQuickSalary = {
                            viewModel.addTransaction(
                                title = "Monthly Salary Credit",
                                amount = 50000.0,
                                isIncome = true,
                                category = "Salary",
                                note = "Auto-added quick credit"
                            )
                        },
                        onQuickSpent = { title, amt, cat ->
                            viewModel.addTransaction(
                                title = title,
                                amount = amt,
                                isIncome = false,
                                category = cat,
                                note = "Quick expense tap"
                            )
                        }
                    )
                }

                // Item 3: Interactive Filter Panel
                item {
                    FilterAndSearchPanel(
                        selectedType = filterType,
                        onTypeClick = { viewModel.setFilterType(it) },
                        selectedCat = selectedCategory,
                        onCatClick = { viewModel.toggleCategoryFilter(it) },
                        searchQuery = searchQuery,
                        onSearchChange = { viewModel.searchQuery.value = it },
                        onClearFilters = { viewModel.clearFilters() }
                    )
                }

                // Item 4: Transactions List Title & Count
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp)
                            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                            .background(MaterialTheme.colorScheme.surface)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Recent Activity",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                if (allTransactionsRaw.isNotEmpty()) {
                                    Text(
                                        text = "Clear All",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .clickable { viewModel.clearAllTransactions() }
                                            .testTag("clear_all_button")
                                    )
                                }
                            }
                        }
                    }
                }

                // Item 5: Transactions List Items
                if (transactions.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface)
                        ) {
                            EmptyStateView(
                                hasFiltersActive = filterType != FilterType.ALL || selectedCategory != null || searchQuery.isNotEmpty()
                            )
                        }
                    }
                } else {
                    items(items = transactions, key = { it.id }) { tx ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surface)
                        ) {
                            TransactionItemRow(
                                transaction = tx,
                                onDelete = { viewModel.deleteTransaction(tx.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    // Modal Dialog: Add Transaction
    if (showAddDialog) {
        AddTransactionDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { title, amount, isIncome, category, note ->
                viewModel.addTransaction(title, amount, isIncome, category, note)
                showAddDialog = false
            }
        )
    }

    // Modal Dialog: Budget Limit Config
    if (showBudgetDialog) {
        ConfigBudgetLimitDialog(
            currentLimit = monthlyBudgetLimit,
            onDismiss = { showBudgetDialog = false },
            onConfirm = { limit ->
                viewModel.updateBudget(limit)
                showBudgetDialog = false
            }
        )
    }

    // Modal Dialog: Comprehensive Monthly Report
    if (showReportDialog) {
        MonthlyReportDialog(
            allTransactions = allTransactionsRaw,
            onDismiss = { showReportDialog = false }
        )
    }
}

@Composable
fun BalanceStatsCard(
    balance: Double,
    credits: Double,
    spends: Double,
    budgetLimit: Double,
    progress: Double,
    onBudgetClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("balance_card"),
        shape = RoundedCornerShape(32.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF4338CA), // indigo-700
                            Color(0xFF6366F1)  // indigo-500
                        )
                    )
                )
                .padding(24.dp)
        ) {
            // Ambient glow layout circle (blur-2xl overlay)
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = 40.dp, y = (-40).dp)
                    .size(170.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.09f))
            )

            Column {
                Text(
                    text = "Total Balance",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFC7D2FE) // indigo-100 / indigo-200
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "₹${formatRupee(balance)}",
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = (-0.5).sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Translucent segment overlay
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color.White.copy(alpha = 0.12f))
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "INCOME",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFC7D2FE),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "+ ₹${formatRupee(credits)}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }

                    // Separation line
                    Box(
                        modifier = Modifier
                            .height(30.dp)
                            .width(1.dp)
                            .background(Color.White.copy(alpha = 0.2f))
                    )

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .wrapContentWidth(Alignment.End),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "SPENDS",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFFC7D2FE),
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "- ₹${formatRupee(spends)}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Spend target and limit meters
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Spend Limit Target",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                    Text(
                        text = "₹${formatRupee(spends)} / ₹${formatRupee(budgetLimit)}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                val isOverBudget = progress > 1.0
                val progressColor = if (isOverBudget) Color(0xFFFCA5A5) else Color(0xFFFDBA74) // Light-red or light-orange accent

                // Custom Track Indicator
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.18f))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(progress.toFloat().coerceAtMost(1f))
                            .fillMaxHeight()
                            .clip(CircleShape)
                            .background(progressColor)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val percentString = String.format(Locale.getDefault(), "%.0f%%", progress * 100)
                    Text(
                        text = "$percentString used",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.8f)
                    )

                    if (isOverBudget) {
                        Text(
                            text = "🚨 LIMIT BREACHED",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    } else {
                        Row(
                            modifier = Modifier.clickable { onBudgetClick() },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Adjust target",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(11.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickFrictionlessActions(
    onQuickSalary: () -> Unit,
    onQuickSpent: (title: String, amount: Double, category: String) -> Unit
) {
    var isSalaryAdded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Text(
            text = "Easy Quick-Log Taps",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                SuggestionChip(
                    onClick = {
                        onQuickSalary()
                        isSalaryAdded = true
                    },
                    label = { 
                        Text(
                            text = if (isSalaryAdded) "Salary logged! ✓" else "+ ₹50k Salary",
                            color = RupeeCreditGreen,
                            fontWeight = FontWeight.Bold
                        ) 
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Work,
                            contentDescription = null,
                            tint = RupeeCreditGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = SuggestionChipDefaults.suggestionChipColors(
                        containerColor = RupeeCreditGreen.copy(alpha = 0.08f)
                    )
                )
            }

            item {
                SuggestionChip(
                    onClick = { onQuickSpent("Chai & Samosa", 40.0, "Food") },
                    label = { Text("₹40 Chai ☕") }
                )
            }

            item {
                SuggestionChip(
                    onClick = { onQuickSpent("Uber / Auto Ride", 120.0, "Travel") },
                    label = { Text("₹120 Auto 🛺") }
                )
            }

            item {
                SuggestionChip(
                    onClick = { onQuickSpent("Lunch Buffet", 220.0, "Food") },
                    label = { Text("₹220 Lunch 🍛") }
                )
            }

            item {
                SuggestionChip(
                    onClick = { onQuickSpent("Mobile Recharge", 299.0, "Bills") },
                    label = { Text("₹299 JIO Bill 📱") }
                )
            }

            item {
                SuggestionChip(
                    onClick = { onQuickSpent("Movie Ticket", 350.0, "Entertainment") },
                    label = { Text("₹350 Movie 🎬") }
                )
            }
        }
    }
}

@Composable
fun FilterAndSearchPanel(
    selectedType: FilterType,
    onTypeClick: (FilterType) -> Unit,
    selectedCat: String?,
    onCatClick: (String) -> Unit,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onClearFilters: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchChange,
            placeholder = { Text("Search logs description...", fontSize = 14.sp) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchChange("") }) {
                        Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                unfocusedIndicatorColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.3f)
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .testTag("search_bar")
        )

        // Income Expense Segment Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val filters = listOf(
                FilterType.ALL to "All Accounts",
                FilterType.INCOME to "Salary/Credits",
                FilterType.EXPENSE to "Spends"
            )

            filters.forEach { (type, label) ->
                val isActive = selectedType == type
                val backColor = if (isActive) MaterialTheme.colorScheme.primary else Color.Transparent
                val textColor = if (isActive) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(backColor)
                        .clickable { onTypeClick(type) }
                        .padding(vertical = 10.dp)
                        .testTag("filter_tab_${type.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium,
                        color = textColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Horizontal Category Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Show Category",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            if (selectedCat != null) {
                Text(
                    text = "Clear Filter",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onClearFilters() }
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        val allCategories = listOf(
            "Salary" to "🎁",
            "Food" to "🍛",
            "Rent" to "🏠",
            "Travel" to "🛺",
            "Shopping" to "🛍️",
            "Bills" to "📱",
            "Entertainment" to "🎬",
            "Medical" to "💊",
            "Bonus" to "💎",
            "Others" to "📦"
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(allCategories) { (cat, emoji) ->
                val isSelected = selectedCat == cat
                val surfaceColor = if (isSelected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.surface
                }
                val textColor = if (isSelected) {
                    Color.White
                } else {
                    MaterialTheme.colorScheme.onSurface
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(surfaceColor)
                        .clickable { onCatClick(cat) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                        .testTag("category_filter_$cat"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = emoji, modifier = Modifier.padding(end = 4.dp), fontSize = 13.sp)
                        Text(
                            text = cat,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = textColor
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionItemRow(
    transaction: Transaction,
    onDelete: () -> Unit
) {
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val format = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
    val dateString = format.format(Date(transaction.date))

    val (emoji, iconBg) = getCategoryStyling(transaction.category, transaction.isIncome)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("transaction_item_${transaction.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Circle Emoji Indicator
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Text(text = emoji, fontSize = 20.sp)
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Title & Timestamp description
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp)
            ) {
                Text(
                    text = transaction.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = transaction.category,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (transaction.isIncome) RupeeCreditGreen else MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = " • $dateString",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
                if (transaction.note.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = transaction.note,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Amount Prefix with Rupees and Delete Button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier.padding(end = 4.dp)
                ) {
                    val prefix = if (transaction.isIncome) "+" else "-"
                    val color = if (transaction.isIncome) RupeeCreditGreen else RupeeDebitRed
                    Text(
                        text = "$prefix ₹${formatRupee(transaction.amount)}",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = color
                    )
                }

                IconButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier.size(28.dp).testTag("delete_tx_button_${transaction.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete transaction",
                        tint = MaterialTheme.colorScheme.secondary.copy(alpha = 0.6f),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Remove Record?", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
            text = { Text("Do you want to delete the transaction log \"${transaction.title}\"?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        onDelete()
                        showDeleteConfirm = false
                    },
                    modifier = Modifier.testTag("confirm_delete_button")
                ) {
                    Text("Delete", color = RupeeDebitRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun EmptyStateView(hasFiltersActive: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp)
            .testTag("empty_state_view"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.surface),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (hasFiltersActive) Icons.Default.FilterList else Icons.Default.AccountBalanceWallet,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.size(40.dp)
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = if (hasFiltersActive) "No records match search" else "No Rupee flows logged",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (hasFiltersActive) {
                "Try relaxing your search terms or tap clear to show all accounts."
            } else {
                "Tap 'Add Entry' to log salary credits, grocery spends, utilities, or investments in INR."
            },
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
    }
}

// Dialog: Add Transaction View Dialog
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddTransactionDialog(
    onDismiss: () -> Unit,
    onConfirm: (title: String, amount: Double, isIncome: Boolean, category: String, note: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountStr by remember { mutableStateOf("") }
    var isIncome by remember { mutableStateOf(false) } // Default is spend (Expense)
    var selectedCategory by remember { mutableStateOf("Food") }
    var note by remember { mutableStateOf("") }

    var errorText by remember { mutableStateOf("") }

    val categories = if (isIncome) {
        listOf("Salary", "Bonus", "Bonus" to "🎁", "Salary" to "🎁", "Bonus" to "💎", "Others" to "📦")
        listOf("Salary", "Bonus", "Bonus", "Others") // category fallback
    } else {
        listOf("Food", "Rent", "Travel", "Shopping", "Bills", "Entertainment", "Medical", "Others")
    }

    // Auto update selectedCategory if switching types when not compatible
    LaunchedEffect(isIncome) {
        if (isIncome) {
            selectedCategory = "Salary"
        } else {
            selectedCategory = "Food"
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            tonalElevation = 6.dp,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "New Rupee Receipt",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                // Segment selector for Income vs Expense
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.background)
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(false to "Spend / Outflow", true to "Salary / Credit").forEach { (typeState, label) ->
                        val isSel = isIncome == typeState
                        val bg = if (isSel) {
                            if (typeState) RupeeCreditGreen else RupeeDebitRed
                        } else {
                            Color.Transparent
                        }
                        val fg = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(bg)
                                .clickable { isIncome = typeState }
                                .padding(vertical = 10.dp)
                                .testTag("add_dialog_type_${if (typeState) "income" else "expense"}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = fg
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Title Input
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Log Title *") },
                    placeholder = { Text("e.g., Weekly Vegetables, June Salary") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_title")
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Amount Double Input
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { input ->
                        if (input.isEmpty() || input.toDoubleOrNull() != null || input.count { it == '.' } <= 1) {
                            amountStr = input
                        }
                    },
                    label = { Text("Amount (in INR ₹) *") },
                    leadingIcon = { Text("₹", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary) },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_amount")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Category Grid Selection Title
                Text(
                    text = "Category *",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Category options with lovely emojis
                val showCategories = if (isIncome) {
                    listOf(
                        "Salary" to "🎁", "Bonus" to "💎", "Investments" to "📈", "Others" to "📦"
                    )
                } else {
                    listOf(
                        "Food" to "🍛", "Rent" to "🏠", "Travel" to "🛺", "Shopping" to "🛍️",
                        "Bills" to "📱", "Entertainment" to "🎬", "Medical" to "💊", "Others" to "📦"
                    )
                }

                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    showCategories.forEach { (cat, emoji) ->
                        val isCatSel = selectedCategory == cat
                        val borderCol = if (isCatSel) MaterialTheme.colorScheme.primary else Color.Transparent
                        val containerBg = if (isCatSel) {
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                        } else {
                            MaterialTheme.colorScheme.background
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(containerBg)
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                                .testTag("add_dialog_category_$cat"),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(emoji, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = cat,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isCatSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Remarks note
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Note / Short Comment") },
                    placeholder = { Text("Optional details...") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_note")
                )

                if (errorText.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorText,
                        color = RupeeDebitRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Bottom Buttons row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            val amount = amountStr.toDoubleOrNull()
                            if (title.trim().isEmpty()) {
                                errorText = "Please write a summary title."
                            } else if (amount == null || amount <= 0) {
                                errorText = "Please type a valid amount greater than 0."
                            } else {
                                onConfirm(title.trim(), amount, isIncome, selectedCategory, note.trim())
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("save_transaction_button")
                    ) {
                        Text("Save Entry", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// Dialog: Set Spending Limit Dialog
@Composable
fun ConfigBudgetLimitDialog(
    currentLimit: Double,
    onDismiss: () -> Unit,
    onConfirm: (limit: Double) -> Unit
) {
    var limitStr by remember { mutableStateOf(currentLimit.toInt().toString()) }
    var errorText by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = "Weekly/Monthly Limit",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Text(
                    text = "Configure maximum spending targets in INR (₹) to track progress bar metrics dynamically.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                OutlinedTextField(
                    value = limitStr,
                    onValueChange = { limitStr = it },
                    label = { Text("Budget Limit (INR ₹) *") },
                    leadingIcon = { Text("₹", fontWeight = FontWeight.Black) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("budget_limit_input")
                )

                if (errorText.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorText,
                        color = RupeeDebitRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Button(
                        onClick = {
                            val l = limitStr.toDoubleOrNull()
                            if (l == null || l <= 0) {
                                errorText = "Please enter a valid amount."
                            } else {
                                onConfirm(l)
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("save_budget_button")
                    ) {
                        Text("Save Limit", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// Helpers
fun formatRupee(amount: Double): String {
    val formatter = java.text.DecimalFormat("#,##,###.##")
    return formatter.format(amount)
}

fun getCategoryStyling(category: String, isIncome: Boolean): Pair<String, Color> {
    return when (category) {
        "Salary" -> "🎁" to RupeeCreditGreen.copy(alpha = 0.15f)
        "Bonus" -> "💎" to Color(0xFFF59E0B).copy(alpha = 0.15f)
        "Investments" -> "📈" to Color(0xFF6366F1).copy(alpha = 0.15f)
        "Food" -> "🍛" to Color(0xFFFF5252).copy(alpha = 0.15f)
        "Rent" -> "🏠" to Color(0xFF3B82F6).copy(alpha = 0.15f)
        "Travel" -> "🛺" to Color(0xFFF59E0B).copy(alpha = 0.15f)
        "Shopping" -> "🛍️" to Color(0xFFEC4899).copy(alpha = 0.15f)
        "Bills" -> "📱" to Color(0xFF8B5CF6).copy(alpha = 0.15f)
        "Entertainment" -> "🎬" to Color(0xFFEF4444).copy(alpha = 0.15f)
        "Medical" -> "💊" to Color(0xFF10B981).copy(alpha = 0.15f)
        else -> "📦" to Color(0xFF64748B).copy(alpha = 0.15f)
    }
}

@Composable
fun MonthlyReportBanner(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clickable { onClick() }
            .testTag("monthly_report_banner"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Analytics,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column {
                    Text(
                        text = "Monthly Financial Report",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Interactive breakdown of savings rate, category shares & tips.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "View Report",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MonthlyReportDialog(
    allTransactions: List<Transaction>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val monthYearFormat = remember { SimpleDateFormat("MMMM yyyy", Locale.getDefault()) }

    // Dynamically obtain all unique month keys containing transactions
    val groupedByMonth = remember(allTransactions) {
        allTransactions.groupBy { monthYearFormat.format(Date(it.date)) }
    }

    val monthKeys = remember(groupedByMonth) {
        groupedByMonth.keys.sortedWith { m1, m2 ->
            try {
                val date1 = monthYearFormat.parse(m1) ?: Date(0)
                val date2 = monthYearFormat.parse(m2) ?: Date(0)
                date2.compareTo(date1) // newest first
            } catch (e: Exception) {
                0
            }
        }
    }

    // Default to the newest month, or the current month if empty
    var selectedMonth by remember(monthKeys) {
        mutableStateOf(
            monthKeys.firstOrNull() ?: monthYearFormat.format(Date())
        )
    }

    // Calculations for the selected month
    val monthTransactions = remember(selectedMonth, allTransactions) {
        allTransactions.filter { monthYearFormat.format(Date(it.date)) == selectedMonth }
    }

    val totalIncome = remember(monthTransactions) {
        monthTransactions.filter { it.isIncome }.sumOf { it.amount }
    }

    val totalExpenses = remember(monthTransactions) {
        monthTransactions.filter { !it.isIncome }.sumOf { it.amount }
    }

    val netSavings = totalIncome - totalExpenses
    val savingsRate = if (totalIncome > 0) (netSavings / totalIncome) else 0.0
    val savingsRatePercent = (savingsRate * 100).coerceAtLeast(0.0)

    val spendsByCategory = remember(monthTransactions) {
        monthTransactions.filter { !it.isIncome }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }
            .toList()
            .sortedByDescending { it.second }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(28.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Topic Header
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Monthly Flow Insights",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close overlay",
                            tint = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }

                // Month Selector horizontal tabs list
                Text(
                    text = "SELECT STATEMENT MONTH",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (monthKeys.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .padding(14.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No logged months found.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                } else {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)
                    ) {
                        items(monthKeys) { month ->
                            val isSel = month == selectedMonth
                            val bg = if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                            val fg = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface
                            
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(bg)
                                    .clickable { selectedMonth = month }
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                                    .testTag("month_tab_$month")
                            ) {
                                Text(
                                    text = month,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = fg
                                )
                            }
                        }
                    }
                }

                // Main Scrollable Report Content area
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Item 1: Overview Savings Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(
                                    text = "STATEMENT SUMMARY ($selectedMonth)",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.secondary
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text("Total Income", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(
                                            "₹${formatRupee(totalIncome)}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RupeeCreditGreen
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text("Total Outflows", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                                        Text(
                                            "₹${formatRupee(totalExpenses)}",
                                            fontSize = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = RupeeDebitRed
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(1.dp)
                                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                                )
                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("Net Monthly Savings", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (netSavings >= 0) "+ ₹${formatRupee(netSavings)}" else "- ₹${formatRupee(kotlin.math.abs(netSavings))}",
                                            fontSize = 22.sp,
                                            fontWeight = FontWeight.Black,
                                            color = if (netSavings >= 0) RupeeCreditGreen else RupeeDebitRed
                                        )
                                    }

                                    // Savings Rate Badge
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(
                                                if (netSavings >= 0) RupeeCreditGreen.copy(alpha = 0.12f)
                                                else RupeeDebitRed.copy(alpha = 0.12f)
                                            )
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                "SAVINGS RATE",
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = if (netSavings >= 0) RupeeCreditGreen else RupeeDebitRed
                                            )
                                            Text(
                                                text = "${String.format(Locale.getDefault(), "%.1f", savingsRatePercent)}%",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Black,
                                                color = if (netSavings >= 0) RupeeCreditGreen else RupeeDebitRed
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Visual Savings Meter bar
                                val rateCoerced = (savingsRatePercent / 100).coerceIn(0.0, 1.0)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(rateCoerced.toFloat())
                                            .fillMaxHeight()
                                            .clip(CircleShape)
                                            .background(if (netSavings >= 0) RupeeCreditGreen else RupeeDebitRed)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Health index title
                                val healthBadge = when {
                                    netSavings < 0 -> "🚨 Budget Deficit (Spent more than earned)"
                                    savingsRatePercent >= 50.0 -> "🏆 Elite Saver (Over 50% savings preserved!)"
                                    savingsRatePercent >= 30.0 -> "🌟 Dynamic Accumulator (Over 30% savings)"
                                    savingsRatePercent >= 10.0 -> "👍 Healthy Cushion (10-30% buffer margin)"
                                    else -> "⚠️ Thin Savings Runway (Under 10% saved)"
                                }

                                Text(
                                    text = healthBadge,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (netSavings >= 0) MaterialTheme.colorScheme.primary else RupeeDebitRed
                                )
                            }
                        }
                    }

                    // Item 2: Expense Category Breakdown Chart List
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(
                                    text = "CATEGORY OUTFLOW BREAKDOWN",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.secondary
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                if (spendsByCategory.isEmpty()) {
                                    Text(
                                        "No registered expenses for this period.",
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                        modifier = Modifier.padding(vertical = 12.dp)
                                    )
                                } else {
                                    val totalSpendsVal = spendsByCategory.sumOf { it.second }

                                    spendsByCategory.forEachIndexed { index, (cat, amt) ->
                                        val pct = if (totalSpendsVal > 0) amt / totalSpendsVal else 0.0
                                        val (emoji, iconBg) = getCategoryStyling(cat, false)

                                        Column(modifier = Modifier.padding(bottom = 12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(text = emoji, fontSize = 16.sp)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = cat,
                                                        fontSize = 13.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                }
                                                Text(
                                                    text = "₹${formatRupee(amt)}  (${String.format(Locale.getDefault(), "%.1f", pct * 100)}%)",
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.SemiBold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))

                                            // Custom category progress bar acting as chart
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(8.dp)
                                                    .clip(CircleShape)
                                                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth(pct.toFloat())
                                                        .fillMaxHeight()
                                                        .clip(CircleShape)
                                                        .background(iconBg.copy(alpha = 0.9f))
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Item 3: Personalized Spending Advisor Rules
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(24.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surface
                            )
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text(
                                    text = "SMART FINANCIAL ADVICE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.secondary
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                val adviceTips = mutableListOf<String>()

                                if (totalIncome == 0.0 && totalExpenses > 0) {
                                    adviceTips.add("No credits logged for $selectedMonth. To compute a valid savings index, track incoming salary or side freelance earnings.")
                                } else if (netSavings < 0) {
                                    adviceTips.add("Negative savings detected: Outflows exceed credits by ₹${formatRupee(kotlin.math.abs(netSavings))}. Consider trimming variable categories immediately.")
                                } else if (savingsRatePercent >= 40.0) {
                                    adviceTips.add("Exceptional work! You saved ${String.format(Locale.getDefault(), "%.1f", savingsRatePercent)}% of your earnings. Consider allocating a portion to secure high-growth assets or recurring deposits.")
                                } else {
                                    adviceTips.add("Standard targets aim for a 20% savings margin. At ${String.format(Locale.getDefault(), "%.1f", savingsRatePercent)}%, you can reach this target by optimizing secondary items.")
                                }

                                if (spendsByCategory.isNotEmpty()) {
                                    val topCat = spendsByCategory.first()
                                    val topPct = (topCat.second / spendsByCategory.sumOf { it.second }) * 100
                                    adviceTips.add("Your leading outflow is on ${topCat.first} contributing ${String.format(Locale.getDefault(), "%.1f", topPct)}% of expenses (₹${formatRupee(topCat.second)}). Streamline this segment to recover ₹${formatRupee(topCat.second * 0.15)} (15% savings boost).")
                                }

                                if (allTransactions.size > 5) {
                                    adviceTips.add("Your logging persistence has logged ${allTransactions.size} transactions total. Continuous weekly reviews increase budget compliance on average by 40%!")
                                }

                                adviceTips.forEach { tip ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Text(text = "💡", fontSize = 14.sp, modifier = Modifier.padding(end = 8.dp, top = 1.dp))
                                        Text(
                                            text = tip,
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.82f),
                                            lineHeight = 17.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Bottom CTA action button to export report text
                Button(
                    onClick = {
                        val reportText = generateReceiptText(
                            month = selectedMonth,
                            income = totalIncome,
                            expenses = totalExpenses,
                            savings = netSavings,
                            rate = savingsRatePercent,
                            spendsByCategory = spendsByCategory
                        )
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Sumanth Monthly Report", reportText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "Copied statement details to Clipboard!", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("copy_report_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Copy & Export Statement",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }
    }
}

private fun generateReceiptText(
    month: String,
    income: Double,
    expenses: Double,
    savings: Double,
    rate: Double,
    spendsByCategory: List<Pair<String, Double>>
): String {
    val delimiter = "--------------------------------------------\n"
    val sb = StringBuilder()
    sb.append("📊 PERSONAL MONTHLY BUDGET STATEMENT\n")
    sb.append("Month Period: $month\n")
    sb.append(delimiter)
    sb.append("Total Income Credits  : ₹${formatRupee(income)}\n")
    sb.append("Total Outflows Spent  : ₹${formatRupee(expenses)}\n")
    sb.append("Net Account Savings   : ₹${formatRupee(savings)}\n")
    sb.append(String.format(Locale.getDefault(), "Savings Safety Index  : %.1f%%\n", rate))
    sb.append(delimiter)
    sb.append("📉 EXPENSES SPLIT:\n")
    if (spendsByCategory.isEmpty()) {
        sb.append("No outward transactions recorded.\n")
    } else {
        val totalExp = spendsByCategory.sumOf { it.second }
        spendsByCategory.forEach { (cat, amt) ->
            val emoji = getCategoryStyling(cat, false).first
            val topPct = if(totalExp > 0) (amt / totalExp) * 100 else 0.0
            sb.append(String.format(Locale.getDefault(), "%s %s: ₹%s (%.1f%%)\n", emoji, cat, formatRupee(amt), topPct))
        }
    }
    sb.append(delimiter)
    sb.append("Copied via Sumanth's Personal Expense Flow Tracker.")
    return sb.toString()
}
